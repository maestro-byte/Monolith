
# Monolith Chat App

A simple real-time chat app for you and your agents, built as a monolith using Express and React with Socket.IO.

## How to Run

1. Install dependencies:
    npm install
    cd client
    npm install
    cd ..

2. Build the React frontend:
    cd client
    npm run build
    cd ..

3. Start the server:
    node server.js

## Visit the app
Open http://localhost:3000
